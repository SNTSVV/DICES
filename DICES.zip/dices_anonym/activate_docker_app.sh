IP="172.17.0.2"

sshpass -p karaf onos karaf@$IP app activate dices
