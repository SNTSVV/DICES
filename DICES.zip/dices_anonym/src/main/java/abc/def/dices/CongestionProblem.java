package abc.def.dices;

import org.onosproject.net.DeviceId;
import org.onosproject.net.Host;
import org.onosproject.net.HostId;
import org.onosproject.net.Link;
import org.onosproject.net.Path;
import org.onosproject.net.flow.FlowEntry;
import org.onosproject.net.host.HostService;
import org.onosproject.net.link.LinkService;
import org.onosproject.net.topology.LinkWeigher;
import org.onosproject.net.topology.TopologyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.uma.jmetal.problem.impl.AbstractIntegerProblem;
import org.uma.jmetal.solution.IntegerSolution;
import org.uma.jmetal.solution.impl.DefaultIntegerSolution;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CongestionProblem extends AbstractIntegerProblem {
    private static final int LOWER_BOUND = 0;
    private final Logger log = LoggerFactory.getLogger(getClass());

    private TopologyService topologyService;
    private LinkService linkService;
    private HostService hostService;
    private MonitorUtil monitorUtil;
    private SearchRunner runner;

    private Map<SrcDstPair, Long> sdTxBitsMap;
    private Map<Link, Long> simLinkThroughputMap;

    private List<SrcDstPair> curSDList;
    private Map<SrcDstPair, List<Path>> sdAltPathListMap;
    private Map<SrcDstPair, List<Link>> sdCurrentPathMap;

    public CongestionProblem(TopologyService topologyService, LinkService linkService, HostService hostService, MonitorUtil monitorUtil) {
        this.topologyService = topologyService;
        this.linkService = linkService;
        this.hostService = hostService;
        this.monitorUtil = monitorUtil;

        this.sdTxBitsMap = new HashMap<>();
        this.simLinkThroughputMap = new HashMap<>();
        this.sdAltPathListMap = new HashMap<>();
        this.sdCurrentPathMap = new HashMap<>();

        setCurSDPath();

        setNumberOfVariables();
        setNumberOfObjectives(3);
        setName("CongestionProblem");
        setLowerUpperLimit();
    }

    private void setCurSDPath() {
        Set<FlowEntry> flowEntrySet = monitorUtil.getAllCurrentFlowEntries();
        Set<SrcDstPair> sdSet = monitorUtil.getAllSrcDstPairs(flowEntrySet);
        curSDList = new ArrayList<>(sdSet);

        Iterator<SrcDstPair> it = curSDList.iterator();
        while (it.hasNext()) {
            SrcDstPair sd = it.next();
            List<Link> dIdPath = monitorUtil.getCurrentPath(sd);
            if (dIdPath == null) {
                it.remove();
                continue;
            }
            sdCurrentPathMap.put(sd, dIdPath);
        }
        log.info("Set current (src,dst) paths");
    }

    private void setLowerUpperLimit() {
        List<Integer> lowerLimit = new ArrayList<>(getNumberOfVariables());
        List<Integer> upperLimit = new ArrayList<>(getNumberOfVariables());

        for (SrcDstPair sd : curSDList) {
            Host srcHost = hostService.getHost(HostId.hostId(sd.src));
            DeviceId srcDevId = srcHost.location().deviceId();
            Host dstHost = hostService.getHost(HostId.hostId(sd.dst));
            DeviceId dstDevId = dstHost.location().deviceId();

            Set<Path> allPathSet =
                    topologyService.getKShortestPaths(
                            topologyService.currentTopology(),
                            srcDevId, dstDevId,
                            DynamicLinkWeight.DYNAMIC_LINK_WEIGHT,
                            Config.MAX_NUM_PATHS);
            lowerLimit.add(LOWER_BOUND);
            upperLimit.add(allPathSet.size()-1);

            sdAltPathListMap.put(sd, new ArrayList<>(allPathSet));
        }

        setLowerLimit(lowerLimit);
        setUpperLimit(upperLimit);
        log.info("Set upper limits " + upperLimit);
    }

    private void setNumberOfVariables() {
        setNumberOfVariables(curSDList.size());
        log.info("Set number of variables: " + curSDList.size());
    }

    public CongestionProblem prepareSearch() {
        initSimLinkThroughputMap();
        updateSDTxBitsMap();
        return this;
    }

    private void initSimLinkThroughputMap() {
        for (Link l : linkService.getLinks()) {
            simLinkThroughputMap.put(l, new Long(0));
        }
    }

    private void updateSDTxBitsMap() {
        for (SrcDstPair sd : curSDList) {
            long deltaTxBits = monitorUtil.getTxBitsPerSec(sd);
            int srcCnt = cntSameSrcInCurFlows(sd);
            deltaTxBits /= srcCnt;
            sdTxBitsMap.put(sd, deltaTxBits);
            /*
            Host srcHost = hostService.getHost(HostId.hostId(sd.src));
            DeviceId srcId = srcHost.location().deviceId();
            Host dstHost = hostService.getHost(HostId.hostId(sd.dst));
            DeviceId dstId = dstHost.location().deviceId();
            log.error("Demand: {}/{} ->  {}/{} {}",
                      srcHost.ipAddresses(), srcId, dstHost.ipAddresses(), dstId, deltaTxBits/1000/1000);
                      */

        }
    }

    private int cntSameSrcInCurFlows(SrcDstPair sd) {
        int cnt = 0;
        for (SrcDstPair cSD : curSDList) {
            if (cSD.src.equals(sd.src)) {
                cnt++;
            }
        }
        return cnt;
    }

    public void setSearchRunner(SearchRunner runnner) {
        this.runner = runnner;
    }

    //private int cnt = 0;

    @Override
    public void evaluate(IntegerSolution solution) {
        /*
        if (++cnt % 1000 == 0) {
            List<IntegerSolution> solutions = runner.getResult();
            IntegerSolution knee = runner.getKneeSolution(solutions);
            if (knee != null) {
                log.error("Cnt {},{},{},{}", cnt, knee.getObjective(0), knee.getObjective(1), knee.getObjective(2));
            }
        }
        */

        initSimLinkThroughputMap();
        updateSimLinkThroughputMap(solution);

        double eu = estimateMaxLinkUtilization();
        solution.setObjective(0, eu);

        long costByDiff = calculateDiffFromOrig(solution);
        if (costByDiff == 0) {
            costByDiff = Config.LARGE_NUM;
        }
        solution.setObjective(1, costByDiff);

        long totalDelay = sumDelay(solution);
        if (eu > Config.UTILIZATION_THRESHOLD) {
            totalDelay = Config.LARGE_NUM;
        }
        solution.setObjective(2, totalDelay);

        /*
        if (cnt % 1000 == 0) {
            log.error("Sol {},{},{},{}", cnt, solution.getObjective(0), solution.getObjective(1), solution.getObjective(2));
        }
        */
    }

    private long sumDelay(IntegerSolution solution) {
        long sum = 0;
        for (int i = 0; i < solution.getNumberOfVariables(); i++) {
            Path sPath = getSolutionPath(solution, i);
            for (Link l : sPath.links()) {
                sum += monitorUtil.getDelay(l);
            }
        }

        return sum;
    }

    private long calculateDiffFromOrig(IntegerSolution solution) {
        int distSum = 0;
        for (int i = 0; i < solution.getNumberOfVariables(); i++) {
            Path sPath = getSolutionPath(solution, i);
            SrcDstPair sd = getSrcDstPair(solution, i);
            List<Link> sLinkPath = sPath.links();
            List<Link> oLinkPath = sdCurrentPathMap.get(sd);
            int dist = editLCSDistance(oLinkPath, sLinkPath);
            distSum += dist;
        }
        return distSum;
    }

    private int editLCSDistance(List<Link> x, List<Link> y) {
        int m = x.size(), n = y.size();
        int l[][] = new int[m+1][n+1];
        for (int i = 0; i <= m; i++) {
            for (int j = 0; j <= n; j++) {
                if (i == 0 || j == 0) {
                    l[i][j] = 0;
                } else if (x.get(i-1).equals(y.get(j-1))) {
                    l[i][j] = l[i-1][j-1] + 1;
                } else {
                    l[i][j] = Math.max(l[i-1][j], l[i][j-1]);
                }
            }
        }
        int lcs = l[m][n];
        return (m - lcs) + (n - lcs);
    }

    public List<Link> findLCS(List<Link> x, List<Link> y) {
        int m = x.size(), n = y.size();
        int l[][] = new int[m+1][n+1];
        for (int i = 0; i <= m; i++) {
            for (int j = 0; j <= n; j++) {
                if (i == 0 || j == 0) {
                    l[i][j] = 0;
                } else if (x.get(i-1).equals(y.get(j-1))) {
                    l[i][j] = l[i-1][j-1] + 1;
                } else {
                    l[i][j] = Math.max(l[i-1][j], l[i][j-1]);
                }
            }
        }

        List<Link> lcs = new ArrayList<>();
        int i = m, j = n;
        while (i > 0 && j > 0) {
            if (x.get(i-1).equals(y.get(j-1))) {
                lcs.add(x.get(i-1));
                i--; j--;
            } else if (l[i-1][j] > l[i][j-1]) {
                i--;
            } else {
                j--;
            }
        }

        Collections.reverse(lcs);
        return lcs;
    }

    public Map<SrcDstPair, List<Link>> getSolutionLinkPath(IntegerSolution solution) {
        Map<SrcDstPair, List<Link>> sdLinkPathMap = new HashMap<>();

        for (int i = 0; i < solution.getNumberOfVariables(); i++) {
            Path sPath = getSolutionPath(solution, i);
            SrcDstPair sd = getSrcDstPair(solution, i);
            sdLinkPathMap.put(sd, sPath.links());
        }

        return sdLinkPathMap;
    }

    public Map<SrcDstPair, List<Link>> getCurrentLinkPath() {
        return sdCurrentPathMap;
    }

    private void updateSimLinkThroughputMap(IntegerSolution solution) {
        for (int i = 0; i < solution.getNumberOfVariables(); i++) {
            Path solutionPath = getSolutionPath(solution, i);
            SrcDstPair sd = getSrcDstPair(solution, i);
            incSimLinkThroughput(solutionPath, sd);
        }
    }

    private SrcDstPair getSrcDstPair(IntegerSolution solution, int idx) {
        return curSDList.get(idx);
    }

    private Path getSolutionPath(IntegerSolution solution, int idx) {
        int sValue = solution.getVariableValue(idx);
        SrcDstPair sd = curSDList.get(idx);
        List<Path> candidatePathList = sdAltPathListMap.get(sd);
        return candidatePathList.get(sValue);
    }

    private double estimateMaxLinkUtilization() {
        double max = 0D;
        for (Link l : linkService.getLinks()) {
            double u = estimateUtilization(l);
            if (max < u) {
                max = u;
            }
        }
        return max;
    }

    public double estimateUtilization(Link l) {
        long throughput = simLinkThroughputMap.get(l);
        return monitorUtil.calculateUtilization(l, throughput);
    }

    private void incSimLinkThroughput(Path path, SrcDstPair sd) {
        Long txBits = sdTxBitsMap.get(sd);
        for (Link l : path.links()) {
            Long linkThroughput = simLinkThroughputMap.get(l);
            simLinkThroughputMap.put(l, linkThroughput+txBits);
        }
    }

    public IntegerSolution createInitialSolution() {
        IntegerSolution solution = new DefaultIntegerSolution(this);
        for (int i = 0; i < solution.getNumberOfVariables(); i++) {
            SrcDstPair sd = curSDList.get(i);
            List<Link> path = sdCurrentPathMap.get(sd);
            List<Path> altPathList = sdAltPathListMap.get(sd);
            for (int j = 0; j < altPathList.size(); j++) {
                if (path.equals(altPathList.get(j).links())) {
                    solution.setVariableValue(i, j);
                }
            }
        }
        return solution;
    }

    public void analyzeSolution(IntegerSolution solution) {
        initSimLinkThroughputMap();
        updateSimLinkThroughputMap(solution);
    }
}
