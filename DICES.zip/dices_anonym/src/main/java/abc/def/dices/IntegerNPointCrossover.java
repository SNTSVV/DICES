package abc.def.dices;

import org.apache.commons.lang3.ArrayUtils;
import org.uma.jmetal.operator.CrossoverOperator;
import org.uma.jmetal.solution.IntegerSolution;
import org.uma.jmetal.util.JMetalException;
import org.uma.jmetal.util.pseudorandom.JMetalRandom;

import java.util.ArrayList;
import java.util.List;

public class IntegerNPointCrossover implements CrossoverOperator<IntegerSolution> {
    private final JMetalRandom randomNumberGenerator = JMetalRandom.getInstance();
    private final double probability;
    private final int crossovers;

    public IntegerNPointCrossover(double probability, int crossovers) {
        if (probability < 0.0D) {
            throw new JMetalException("Probability can't be negative");
        } else if (crossovers < 1) {
            throw new JMetalException("Number of crossovers is less than one");
        } else {
            this.probability = probability;
            this.crossovers = crossovers;
        }
    }

    public IntegerNPointCrossover(int crossovers) {
        this.crossovers = crossovers;
        this.probability = 1.0D;
    }

    public double getCrossoverProbability() {
        return this.probability;
    }

    public List<IntegerSolution> execute(List<IntegerSolution> s) {
        if (this.getNumberOfRequiredParents() != s.size()) {
            throw new JMetalException("Point Crossover requires + " + this.getNumberOfRequiredParents() + " parents, but got " + s.size());
        } else {
            return this.randomNumberGenerator.nextDouble() < this.probability ? this.doCrossover(s) : s;
        }
    }

    private List<IntegerSolution> doCrossover(List<IntegerSolution> s) {
        IntegerSolution mom = s.get(0);
        IntegerSolution dad = s.get(1);
        if (mom.getNumberOfVariables() != dad.getNumberOfVariables()) {
            throw new JMetalException("The 2 parents doesn't have the same number of variables");
        } else if (mom.getNumberOfVariables() < this.crossovers) {
            throw new JMetalException("The number of crossovers is higher than the number of variables");
        } else {
            int[] crossoverPoints = new int[this.crossovers];

            for(int i = 0; i < crossoverPoints.length; ++i) {
                crossoverPoints[i] = this.randomNumberGenerator.nextInt(0, mom.getNumberOfVariables() - 1);
            }

            IntegerSolution girl = (IntegerSolution)mom.copy();
            IntegerSolution boy = (IntegerSolution)dad.copy();
            boolean swap = false;

            for(int i = 0; i < mom.getNumberOfVariables(); ++i) {
                if (swap) {
                    boy.setVariableValue(i, mom.getVariableValue(i));
                    girl.setVariableValue(i, dad.getVariableValue(i));
                }

                if (ArrayUtils.contains(crossoverPoints, i)) {
                    swap = !swap;
                }
            }

            List<IntegerSolution> result = new ArrayList();
            result.add(girl);
            result.add(boy);
            return result;
        }
    }

    public int getNumberOfRequiredParents() {
        return 2;
    }

    public int getNumberOfGeneratedChildren() {
        return 2;
    }
}
