package abc.def.dices;

import org.uma.jmetal.operator.MutationOperator;
import org.uma.jmetal.solution.IntegerSolution;
import org.uma.jmetal.util.JMetalException;
import org.uma.jmetal.util.pseudorandom.JMetalRandom;
import org.uma.jmetal.util.pseudorandom.RandomGenerator;

public class IntegerUniformMutation implements MutationOperator<IntegerSolution> {
    private double perturbation;
    private Double mutationProbability = null;
    private RandomGenerator<Double> randomGenenerator ;

    /** Constructor */
    public IntegerUniformMutation(double mutationProbability) {
        this(mutationProbability, 0, () -> JMetalRandom.getInstance().nextDouble());
    }

    public IntegerUniformMutation(double mutationProbability, double perturbation) {
        this(mutationProbability, perturbation, () -> JMetalRandom.getInstance().nextDouble());
    }

    /** Constructor */
    public IntegerUniformMutation(double mutationProbability, double perturbation, RandomGenerator<Double> randomGenenerator) {
        this.mutationProbability = mutationProbability ;
        this.perturbation = perturbation ;
        this.randomGenenerator = randomGenenerator ;
    }

    /* Getters */
    public double getPerturbation() {
        return perturbation;
    }

    public Double getMutationProbability() {
        return mutationProbability;
    }

    /* Setters */
    public void setPerturbation(Double perturbation) {
        this.perturbation = perturbation;
    }

    public void setMutationProbability(Double mutationProbability) {
        this.mutationProbability = mutationProbability;
    }

    /**
     * Perform the operation
     *
     * @param probability Mutation setProbability
     * @param solution    The solution to mutate
     */
    public void doMutation(double probability, IntegerSolution solution)  {
        for (int i = 0; i < solution.getNumberOfVariables(); i++) {
            if (randomGenenerator.getRandomValue() < probability) {
                double rand = randomGenenerator.getRandomValue();
                double tmp = solution.getLowerBound(i) +
                        (solution.getUpperBound(i) - solution.getLowerBound(i)) * rand;
                int mutatedValue = (int)Math.round(tmp);
                solution.setVariableValue(i, mutatedValue);
            }
        }
    }

    /** Execute() method */
    @Override
    public IntegerSolution execute(IntegerSolution solution) {
        if (null == solution) {
            throw new JMetalException("Null parameter");
        }

        doMutation(mutationProbability, solution);

        return solution;
    }
}
