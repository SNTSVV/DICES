package abc.def.dices;

import org.uma.jmetal.algorithm.multiobjective.nsgaii.NSGAII;
import org.uma.jmetal.operator.CrossoverOperator;
import org.uma.jmetal.operator.MutationOperator;
import org.uma.jmetal.operator.SelectionOperator;
import org.uma.jmetal.problem.Problem;
import org.uma.jmetal.solution.Solution;
import org.uma.jmetal.util.comparator.DominanceComparator;
import org.uma.jmetal.util.evaluator.SolutionListEvaluator;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class NSGAIICongestion<S extends Solution<?>> extends NSGAII<S> {

    public NSGAIICongestion(Problem<S> problem,
                            int maxEvaluations,
                            int populationSize,
                            CrossoverOperator<S> crossoverOperator,
                            MutationOperator<S> mutationOperator,
                            SelectionOperator<List<S>, S> selectionOperator,
                            SolutionListEvaluator<S> evaluator) {
        this(problem, maxEvaluations, populationSize, crossoverOperator,
             mutationOperator, selectionOperator, new DominanceComparator(),
             evaluator);
    }

    public NSGAIICongestion(Problem<S> problem,
                            int maxEvaluations,
                            int populationSize,
                            CrossoverOperator<S> crossoverOperator,
                            MutationOperator<S> mutationOperator,
                            SelectionOperator<List<S>, S> selectionOperator,
                            Comparator<S> dominanceComparator,
                            SolutionListEvaluator<S> evaluator) {
        super(problem, maxEvaluations, populationSize, crossoverOperator,
             mutationOperator, selectionOperator, dominanceComparator,
             evaluator);
    }

    protected List<S> createInitialPopulation() {
        List<S> population = new ArrayList(this.getMaxPopulationSize());

        CongestionProblem problem = (CongestionProblem)getProblem();
        S initSolution = (S)problem.createInitialSolution();
        population.add(initSolution);

        for(int i = 0; i < getMaxPopulationSize(); ++i) {
            S newIndividual = getMutationOperator().execute(initSolution);
            population.add(newIndividual);
        }

        return population;
    }
}
