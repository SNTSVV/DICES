package abc.def.dices;

import org.uma.jmetal.algorithm.multiobjective.nsgaii.NSGAII;
import org.uma.jmetal.operator.CrossoverOperator;
import org.uma.jmetal.operator.MutationOperator;
import org.uma.jmetal.operator.SelectionOperator;
import org.uma.jmetal.operator.impl.selection.BinaryTournamentSelection;
import org.uma.jmetal.problem.Problem;
import org.uma.jmetal.solution.Solution;
import org.uma.jmetal.util.AlgorithmBuilder;
import org.uma.jmetal.util.JMetalException;
import org.uma.jmetal.util.comparator.DominanceComparator;
import org.uma.jmetal.util.comparator.RankingAndCrowdingDistanceComparator;
import org.uma.jmetal.util.evaluator.SolutionListEvaluator;
import org.uma.jmetal.util.evaluator.impl.SequentialSolutionListEvaluator;

import java.util.Comparator;
import java.util.List;

public class NSGAIICongestionBuilder<S extends Solution<?>> implements AlgorithmBuilder<NSGAII<S>> {
        private final Problem<S> problem;
    private int maxEvaluations;
    private int populationSize;
    private CrossoverOperator<S> crossoverOperator;
    private MutationOperator<S> mutationOperator;
    private SelectionOperator<List<S>, S> selectionOperator;
    private SolutionListEvaluator<S> evaluator;
    private Comparator<S> dominanceComparator;
    private NSGAIICongestionBuilder.NSGAIIVariant variant;

    public NSGAIICongestionBuilder(Problem<S> problem, CrossoverOperator<S> crossoverOperator, MutationOperator<S> mutationOperator) {
        this.problem = problem;
        this.maxEvaluations = 25000;
        this.populationSize = 100;
        this.crossoverOperator = crossoverOperator;
        this.mutationOperator = mutationOperator;
        this.selectionOperator = new BinaryTournamentSelection(new RankingAndCrowdingDistanceComparator());
        this.evaluator = new SequentialSolutionListEvaluator();
        this.dominanceComparator = new DominanceComparator();
        this.variant = NSGAIICongestionBuilder.NSGAIIVariant.NSGAII;
    }

    public NSGAIICongestionBuilder<S> setMaxEvaluations(int maxEvaluations) {
        if (maxEvaluations < 0) {
            throw new JMetalException("maxEvaluations is negative: " + maxEvaluations);
        } else {
            this.maxEvaluations = maxEvaluations;
            return this;
        }
    }

    public NSGAIICongestionBuilder<S> setPopulationSize(int populationSize) {
        if (populationSize < 0) {
            throw new JMetalException("Population size is negative: " + populationSize);
        } else {
            this.populationSize = populationSize;
            return this;
        }
    }

    public NSGAIICongestionBuilder<S> setSelectionOperator(SelectionOperator<List<S>, S> selectionOperator) {
        if (selectionOperator == null) {
            throw new JMetalException("selectionOperator is null");
        } else {
            this.selectionOperator = selectionOperator;
            return this;
        }
    }

    public NSGAIICongestionBuilder<S> setSolutionListEvaluator(SolutionListEvaluator<S> evaluator) {
        if (evaluator == null) {
            throw new JMetalException("evaluator is null");
        } else {
            this.evaluator = evaluator;
            return this;
        }
    }

    public NSGAIICongestionBuilder<S> setDominanceComparator(Comparator<S> dominanceComparator) {
        if (dominanceComparator == null) {
            throw new JMetalException("dominanceComparator is null");
        } else {
            this.dominanceComparator = dominanceComparator;
            return this;
        }
    }

    public NSGAIICongestionBuilder<S> setVariant(NSGAIICongestionBuilder.NSGAIIVariant variant) {
        this.variant = variant;
        return this;
    }

    public NSGAIICongestion<S> build() {
        NSGAIICongestion<S> algorithm = null;
        algorithm = new NSGAIICongestion(this.problem, this.maxEvaluations, this.populationSize, this.crossoverOperator, this.mutationOperator, this.selectionOperator, this.dominanceComparator, this.evaluator);
        return algorithm;
    }

    public Problem<S> getProblem() {
        return this.problem;
    }

    public int getMaxIterations() {
        return this.maxEvaluations;
    }

    public int getPopulationSize() {
        return this.populationSize;
    }

    public CrossoverOperator<S> getCrossoverOperator() {
        return this.crossoverOperator;
    }

    public MutationOperator<S> getMutationOperator() {
        return this.mutationOperator;
    }

    public SelectionOperator<List<S>, S> getSelectionOperator() {
        return this.selectionOperator;
    }

    public SolutionListEvaluator<S> getSolutionListEvaluator() {
        return this.evaluator;
    }

    public static enum NSGAIIVariant {
        NSGAII,
        SteadyStateNSGAII,
        Measures,
        NSGAII45;

        private NSGAIIVariant() {
        }
    }
}
