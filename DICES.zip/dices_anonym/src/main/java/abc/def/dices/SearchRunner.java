package abc.def.dices;

import org.onosproject.net.Link;
import org.onosproject.net.host.HostService;
import org.onosproject.net.link.LinkService;
import org.onosproject.net.topology.TopologyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.uma.jmetal.algorithm.multiobjective.nsgaii.NSGAII;
import org.uma.jmetal.operator.CrossoverOperator;
import org.uma.jmetal.operator.MutationOperator;
import org.uma.jmetal.operator.SelectionOperator;
import org.uma.jmetal.operator.impl.selection.BinaryTournamentSelection;
import org.uma.jmetal.problem.IntegerProblem;
import org.uma.jmetal.solution.IntegerSolution;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SearchRunner {
    private final Logger log = LoggerFactory.getLogger(getClass());

    private TopologyService topologyService;
    private LinkService linkService;
    private MonitorUtil monitorUtil;
    private HostService hostService;

    NSGAIICongestion<IntegerSolution> algorithm;
    private List<IntegerSolution> solutions;
    private IntegerProblem problem;
    private IntegerSolution kneeSolution;

    private Map<SrcDstPair, List<Link>> sdLinkToDelMap;
    private Map<SrcDstPair, List<Link>> sdLinkToAddMap;

    public SearchRunner(TopologyService topologyService, LinkService linkService, HostService hostService, MonitorUtil monitorUtil) {
        this.topologyService = topologyService;
        this.linkService = linkService;
        this.hostService = hostService;
        this.monitorUtil = monitorUtil;

        this.kneeSolution = null;
    }

    public void search() {
        long initTime = System.currentTimeMillis();

        CrossoverOperator<IntegerSolution> crossover;
        MutationOperator<IntegerSolution> mutation;
        SelectionOperator<List<IntegerSolution>, IntegerSolution> selection;

        problem = new CongestionProblem(topologyService, linkService, hostService, monitorUtil)
                .prepareSearch();
        ((CongestionProblem)problem).setSearchRunner(this);
        crossover = new IntegerNPointCrossover(0.8, 1);
        mutation = new IntegerUniformMutation(1.0 / problem.getNumberOfVariables());
        selection = new BinaryTournamentSelection<IntegerSolution>();

        algorithm = new NSGAIICongestionBuilder<IntegerSolution>(problem, crossover, mutation)
                .setPopulationSize(100)
                .setMaxEvaluations(10000)
                .setSelectionOperator(selection)
                .build();
        runAlgorithm(algorithm);

        solutions = algorithm.getResult();
        kneeSolution = getKneeSolution(solutions);
        logKneeSolution();

        long computingTime = System.currentTimeMillis() - initTime;
        log.info("Search time (ms): " + computingTime);
    }

    public void logKneeSolution() {
        if (kneeSolution == null) {
            return;
        }
        for (int i = 0; i < problem.getNumberOfObjectives(); i++) {
            log.info("Fitness " + i + ": " + kneeSolution.getObjective(i));
        }

    }

    public Map<SrcDstPair, List<Link>> getCurrentLinkPath() {
        return ((CongestionProblem)problem).getCurrentLinkPath();
    }

    public Map<SrcDstPair, List<Link>> getSolutionLinkPath() {
        return ((CongestionProblem)problem).getSolutionLinkPath(kneeSolution);
    }

    public List<Link> findLCS(List<Link> x, List<Link> y) {
        return ((CongestionProblem)problem).findLCS(x, y);
    }

    private void runAlgorithm(NSGAII<IntegerSolution> algorithm) {
        //AlgorithmRunner algorithmRunner = new AlgorithmRunner.Executor(algorithm)
        //       .execute();

        try {
            algorithm.run();
        } catch (Exception e) {
            log.error("Error: " + e);
        }
    }

    public List<IntegerSolution> getResult() {
        return algorithm.getResult();
    }

    public IntegerSolution getKneeSolution(List<IntegerSolution> solutions) {
        if (solutions.size() == 0) {
            return null;
        }

        List<IntegerSolution> validSolutions = new ArrayList<>(solutions);
        for (IntegerSolution s : solutions) {
            for (int i = 0; i < s.getNumberOfObjectives(); i++) {
                if (s.getObjective(i) == Config.LARGE_NUM) {
                    validSolutions.remove(s);
                }
            }
        }

        IntegerSolution kneeSolution = null;
        int nobj = problem.getNumberOfObjectives();
        double minValue[] = new double[nobj];
        double maxValue[] = new double[nobj];
        for (int i = 0; i < nobj; i++) {
            minValue[i] = Double.MAX_VALUE;
            maxValue[i] = 0;
        }

        double value[] = new double[nobj];
        for (int i = 0; i < validSolutions.size(); i++) {
            for (int oIdx = 0; oIdx < nobj; oIdx++) {
                value[oIdx] = validSolutions.get(i).getObjective(oIdx);
                if (minValue[oIdx] > value[oIdx]) {
                    minValue[oIdx] = value[oIdx];
                }
                if (maxValue[oIdx] < value[oIdx]) {
                    maxValue[oIdx] = value[oIdx];
                }
            }
        }

        double minDist = Double.MAX_VALUE;
        for (int i = 0; i < validSolutions.size(); i++) {
            double dist = 0D;
            for (int oIdx = 0; oIdx < nobj; oIdx++) {
                value[oIdx] = validSolutions.get(i).getObjective(oIdx);
                double norm = 1;
                if (maxValue[oIdx] > minValue[oIdx]) {
                    norm = (value[oIdx] - minValue[oIdx]) / (maxValue[oIdx] - minValue[oIdx]);
                }
                dist += Math.pow(norm, 2);
            }
            dist = Math.sqrt(dist);
            if (minDist > dist) {
                minDist = dist;
                kneeSolution = validSolutions.get(i);
            }
        }

        if (kneeSolution == null) {
            log.error("Knee solution == null");
            return null;
        }

        return kneeSolution;
    }

    public boolean isSolvable() {
        if (kneeSolution == null) {
            return false;
        }

        /*
        if (kneeSolution.getObjective(0) > Config.UTILIZATION_THRESHOLD) {
            return false;
        }*/

        return true;
    }

    public void analyzeSolution() {
        ((CongestionProblem)problem).analyzeSolution(kneeSolution);
    }

    public double estimateUtilization(Link l) {
        return ((CongestionProblem)problem).estimateUtilization(l);
    }
}
