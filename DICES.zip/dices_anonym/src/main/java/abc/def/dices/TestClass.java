package abc.def.dices;


public class TestClass {
}
