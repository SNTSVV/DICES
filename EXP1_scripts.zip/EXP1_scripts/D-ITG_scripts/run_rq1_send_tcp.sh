DIR="~/PATH"
LOG="LOG"

# Internet sender 1
bash -i -l -c 'sshpass -p svv \
ssh -oStrictHostKeyChecking=no svv@10.0.0.1 \
"cd '$DIR' && \
D-ITG-2.8.1-r1023/bin/ITGSend -s 0.5 -t 100000 -a 10.0.0.12 -rp 10005 -E 3650 -e 1250 -T TCP -l '$LOG'_1" &'

# Internet sender 2
bash -i -l -c 'sshpass -p svv \
ssh -oStrictHostKeyChecking=no svv@10.0.0.2 \
"cd '$DIR' && \
D-ITG-2.8.1-r1023/bin/ITGSend -s 0.5 -t 100000 -a 10.0.0.12 -rp 10005 -E 3650 -e 1250 -T TCP -l '$LOG'_2" &'

sleep 10

# Internet sender 3
bash -i -l -c 'sshpass -p svv \
ssh -oStrictHostKeyChecking=no svv@10.0.0.3 \
"cd '$DIR' && \
D-ITG-2.8.1-r1023/bin/ITGSend -s 0.5 -t 100000 -a 10.0.0.12 -rp 10005 -E 3650 -e 1250 -T TCP -l '$LOG'_3" &'


# Internet sender 4
bash -i -l -c 'sshpass -p svv \
ssh -oStrictHostKeyChecking=no svv@10.0.0.4 \
"cd '$DIR' && \
D-ITG-2.8.1-r1023/bin/ITGSend -s 0.5 -t 100000 -a 10.0.0.12 -rp 10005 -E 3650 -e 1250 -T TCP -l '$LOG'_4" &'


sleep 10

# Internet sender 5
bash -i -l -c 'sshpass -p svv \
ssh -oStrictHostKeyChecking=no svv@10.0.0.5 \
"cd '$DIR' && \
D-ITG-2.8.1-r1023/bin/ITGSend -s 0.5 -t 100000 -a 10.0.0.12 -rp 10005 -E 3650 -e 1250 -T TCP -l '$LOG'_5" &'


# Internet sender 6
bash -i -l -c 'sshpass -p svv \
ssh -oStrictHostKeyChecking=no svv@10.0.0.6 \
"cd '$DIR' && \
D-ITG-2.8.1-r1023/bin/ITGSend -s 0.5 -t 100000 -a 10.0.0.12 -rp 10005 -E 3650 -e 1250 -T TCP -l '$LOG'_6" &'

sleep 10

# Internet sender 7
bash -i -l -c 'sshpass -p svv \
ssh -oStrictHostKeyChecking=no svv@10.0.0.7 \
"cd '$DIR' && \
D-ITG-2.8.1-r1023/bin/ITGSend -s 0.5 -t 100000 -a 10.0.0.12 -rp 10005 -E 3650 -e 1250 -T TCP -l '$LOG'_7" &'

# Internet sender 8
bash -i -l -c 'sshpass -p svv \
ssh -oStrictHostKeyChecking=no svv@10.0.0.8 \
"cd '$DIR' && \
D-ITG-2.8.1-r1023/bin/ITGSend -s 0.5 -t 100000 -a 10.0.0.12 -rp 10005 -E 3650 -e 1250 -T TCP -l '$LOG'_8" &'
